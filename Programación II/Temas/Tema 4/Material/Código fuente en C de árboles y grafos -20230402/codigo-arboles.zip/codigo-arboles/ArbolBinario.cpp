#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct nodo_arbol_bin{
	int valor;
	struct nodo_arbol_bin *izq;
	struct nodo_arbol_bin *der;
} NODO_ARBOL_BIN, *P_NODO_ARBOL_BIN;

typedef struct nodo_arbol_bin * ARBOL_BIN;

/////////////////
//// Creaci�n
/////////////////

void crea_arbol_bin (ARBOL_BIN * abin) {
     *abin = NULL;   
}

///////
// Consulta
///////

bool es_vacio_arbol_bin( ARBOL_BIN abin ) {
     return (abin == NULL? true: false);
}

bool es_vacio_nodo (P_NODO_ARBOL_BIN nodo) {
     return (nodo == NULL ? true: false);                               
}

int obtener_info_nodo (P_NODO_ARBOL_BIN nodo) {
    return (nodo->valor);
}

//////
/// Posicionamiento
///////

P_NODO_ARBOL_BIN obtener_raiz(ARBOL_BIN abin) {
     return ((P_NODO_ARBOL_BIN) abin);                            
}

P_NODO_ARBOL_BIN obtener_hijo_izquierdo (P_NODO_ARBOL_BIN nodo) {
     return nodo->izq;                               
}

P_NODO_ARBOL_BIN obtener_hijo_derecho (P_NODO_ARBOL_BIN nodo) {
     return nodo->der;                               
}


///////
// Modificaci�n
///////

void modifica_info_nodo (P_NODO_ARBOL_BIN nodo, int v) {
    nodo->valor=v;
}


void insertar_hijo_izquierdo(ARBOL_BIN * abin, P_NODO_ARBOL_BIN nodo, int v) {
 
     P_NODO_ARBOL_BIN nuevo_nodo = (P_NODO_ARBOL_BIN) malloc(sizeof(NODO_ARBOL_BIN));
     nuevo_nodo->valor = v;
     nuevo_nodo->der=NULL;
     nuevo_nodo->izq=NULL;
     
     if (es_vacio_arbol_bin(*abin)){
        // Inserci�n en �rbol vac�o (insertamos ra�z)    
        (*abin)=nuevo_nodo;                     
     }
     else {
        // Inserci�n normal en �rbol no vac�o
        nodo->izq=nuevo_nodo;  
     }     
}

void insertar_hijo_derecho(ARBOL_BIN * abin, P_NODO_ARBOL_BIN nodo, int v) {
 
     P_NODO_ARBOL_BIN nuevo_nodo = (P_NODO_ARBOL_BIN) malloc(sizeof(NODO_ARBOL_BIN));
     nuevo_nodo->valor = v;
     nuevo_nodo->der=NULL;
     nuevo_nodo->izq=NULL;
     
     if (es_vacio_arbol_bin(*abin)){
        // Inserci�n en �rbol vac�o (insertamos ra�z)    
        (*abin)=nuevo_nodo;                     
     }
     else {
        // Inserci�n normal en �rbol no vac�o
        nodo->der=nuevo_nodo;  
     }     
}

void eliminar_hijo_derecho(P_NODO_ARBOL_BIN nodo);

void eliminar_hijo_izquierdo(P_NODO_ARBOL_BIN nodo) {
 
     P_NODO_ARBOL_BIN nodoaux = nodo->izq;
     
     if (es_vacio_nodo(nodoaux))
        return;
     
     if(!es_vacio_nodo(obtener_hijo_izquierdo(nodoaux)))
           eliminar_hijo_izquierdo(obtener_hijo_izquierdo(nodoaux));
     
     if(!es_vacio_nodo(obtener_hijo_derecho(nodoaux)))
           eliminar_hijo_derecho(obtener_hijo_derecho(nodoaux));       
     
     free(nodoaux);
     nodo->izq=NULL;
}


void eliminar_hijo_derecho(P_NODO_ARBOL_BIN nodo) {
 
     P_NODO_ARBOL_BIN nodoaux = nodo->der;
     
     if (es_vacio_nodo(nodoaux))
        return;
     
     if(!es_vacio_nodo(obtener_hijo_izquierdo(nodoaux)))
           eliminar_hijo_izquierdo(obtener_hijo_izquierdo(nodoaux));
     
     if(!es_vacio_nodo(obtener_hijo_derecho(nodoaux)))
           eliminar_hijo_derecho(obtener_hijo_derecho(nodoaux));       
     
     free(nodoaux);
     nodo->der=NULL;
}

void destruir_arbol_bin(ARBOL_BIN * abin) {

     P_NODO_ARBOL_BIN raiz = *abin ;

     if(!es_vacio_nodo(obtener_hijo_izquierdo(raiz)))
           eliminar_hijo_izquierdo(obtener_hijo_izquierdo(raiz));
     
     if(!es_vacio_nodo(obtener_hijo_derecho(raiz)))
           eliminar_hijo_derecho(obtener_hijo_derecho(raiz));       
     
     free(raiz);
     *abin=NULL;
}

int main(void){

    int opcion, valoraux;
    ARBOL_BIN arbol = NULL;
    P_NODO_ARBOL_BIN nodoactual =NULL, nodoaux=NULL;
    
    do{
        printf("\n\n1.Crear\n");
        printf("2. Es vacio\n");
        printf("3. Posicionarse en ra�z\n");
        printf("4. Avanzar hijo izquierdo\n");
        printf("5. Avanzar hijo derecho\n");;
        printf("6. Obtener info nodo actual\n");
        printf("7. Modificar valor nodo actual\n");
        printf("8. Insertar hijo izquierdo\n");
        printf("9. Insertar hijo derecho\n");
        printf("10. Eliminar hijo izquierdo\n");
        printf("11. Eliminar hijo derecho\n");
        printf("12. Destruir �rbol\n");   
        printf("13. Salir\n");

      
        printf("\nIntroduce una opcion: ");
        scanf("%d",&opcion);
   
        switch (opcion){
            case 1: 
                 if(!es_vacio_arbol_bin(arbol)) {
                    destruir_arbol_bin(&arbol);
                    printf("Destruido �rbol existente...\n");
                 }  
                 crea_arbol_bin(&arbol);
                 nodoactual=NULL;
                 printf("Arbol creado con exito...");
                 break;
            case 2:
                  if (es_vacio_arbol_bin(arbol)) printf ("El arbol es vacio: no contiene ning�n elemento\n");
                  else ("El arbol no est� vacio y contiene elementos\n");
                  break;
            case 3:
                 if (es_vacio_arbol_bin(arbol)) 
                      printf ("El arbol es vacio: no existe ra�z\n");
                 else {
                      nodoactual = obtener_raiz(arbol);
                      printf("Ra�z obtenida...\n");
                 }
                 break;
            case 4:
                 if(es_vacio_nodo(nodoactual)) {
                       printf("Error. No se puede avanzar, nodoactual es vac�o\n");                       
                       break;
                 }
                 nodoaux=obtener_hijo_izquierdo(nodoactual);
                 if(es_vacio_nodo(nodoaux)) 
                     printf("Error. No se puede avanzar, hijo izquierdo es vac�o\n");
                 else
                     nodoactual = nodoaux;
                 printf("Avanzado hacia hijo izquierdo...");           
                 break;
            case 5:
                 if(es_vacio_nodo(nodoactual)) {
                       printf("Error. No se puede avanzar, nodoactual es vac�o\n");                       
                       break;
                 }
                 nodoaux=obtener_hijo_derecho(nodoactual);
                 if(es_vacio_nodo(nodoaux)) 
                     printf("Error. No se puede avanzar, hijo derecho es vac�o\n");
                 else
                     nodoactual = nodoaux;
                 printf("Avanzado hacia hijo derecho...");                 
                 break;
            case 6:
                 if(es_vacio_nodo(nodoactual)) {
                       printf("Error: no se puede mostrar informaci�n, nodoactual es vac�o\n");                       
                       break;
                 }
                 printf("  - Valor nodo actual = %d\n", nodoactual->valor);
                 if (es_vacio_nodo(obtener_hijo_derecho(nodoactual)))
                    printf("  - No existe hijo derecho\n");
                 else
                    printf("  - Existe hijo derecho\n");
                 if (es_vacio_nodo(obtener_hijo_izquierdo(nodoactual)))
                    printf("  - No existe hijo izquierdo\n");    
                 else
                    printf("  - Existe hijo izquierdo\n");   
                           
                 break;
            case 7:
                  if(es_vacio_nodo(nodoactual)) {
                       printf("Error. No se puede modificar, nodoactual es vac�o\n");                       
                       break;
                  }
                  printf("Introduzca nuevo valor nodo actual:");
                  scanf("%d",&valoraux);
                  
                  modifica_info_nodo(nodoactual,valoraux);
                  printf("Valor modificado con �xito\n");
                  
                  break;
                  
            case 8:
                                 
                 printf("Introduzca nuevo valor para nuevo hijo izquierdo:");
                 scanf("%d",&valoraux);
                 
                 if(es_vacio_arbol_bin(arbol)) {
                       printf("Se est� insertando la ra�z del arbol\n"); 
                       insertar_hijo_izquierdo(&arbol, nodoactual,valoraux); 
                       nodoactual = obtener_raiz(arbol); 
                       printf("Nodo raiz insertado. Posicionado en la raiz del arbol...\n");
                 }
                 else {
                      insertar_hijo_izquierdo(&arbol, nodoactual,valoraux);   
                      printf("Hijo izquierdo insertado..\n");
                 }  
                 
                 break;
                 
            case 9:
                                 
                 printf("Introduzca valor para nuevo hijo derecho:");
                 scanf("%d",&valoraux);
                 
                 if(es_vacio_arbol_bin(arbol)) {
                       printf("Se esta insertando la raiz del arbol\n"); 
                       insertar_hijo_derecho(&arbol, nodoactual,valoraux); 
                       nodoactual = obtener_raiz(arbol);
                       printf("Nodo raiz insertado. Posicionado en la raiz del arbol...\n");
                 }
                 else {
                      insertar_hijo_derecho(&arbol, nodoactual,valoraux);  
                      printf("Hijo derecho insertado..\n");
                 }
                                                  
                 break;
                 
           case 10: 
                 
                 if (es_vacio_nodo(nodoactual)) {
                    printf("No se puede eliminar hijo izquierdo, nodo actual es vac�o\n");
                    break;
                 }
                 
                 eliminar_hijo_izquierdo(nodoactual);
                 printf("Hijo izquierdo eliminado con �xito..");
                 
                 break;
                    
             case 11: 
                 
                 if (es_vacio_nodo(nodoactual)) {
                    printf("No se puede eliminar hijo derecho, nodo actual es vac�o\n");
                    break;
                 }
                 
                 eliminar_hijo_derecho(nodoactual); 
                 printf("Hijo derecho eliminado con �xito..");
                       
                 break;
     
              case 12:
                   if (!es_vacio_arbol_bin(arbol)) {
                      destruir_arbol_bin(&arbol);
                      nodoactual=NULL;
                      printf("�rbol destruido...\n");
                      }
                   else 
                       printf("El �rbol es vac�o, no se puede destruir...\n");
                   
                   break;
     
          }
    }while (opcion != 13);
    
    system("pause");
    return 0;    
}
