#include <stdio.h>
#include <stdlib.h>

typedef struct nodo_arbol{
	int valor;
	struct nodo_arbol *izq;
	struct nodo_arbol *der;
} NODO_ARBOL, *P_NODO_ARBOL;

P_NODO_ARBOL insertar(P_NODO_ARBOL arbol, int i){ 
             
             P_NODO_ARBOL p;
             if (arbol == NULL){ 
                       p = (P_NODO_ARBOL) malloc(sizeof (struct nodo_arbol)); 
                       p->izq = p->der = NULL; 
                       p->valor = i;
                       return p; 
             } 
             if (arbol->valor == i){ 
                              return arbol; 
             }
             if (arbol->valor > i){ 
                    arbol->izq = insertar(arbol->izq, i); 
             }else{ 
                    arbol->der = insertar(arbol->der, i); 
             }
             return arbol; 
}

int pertenece(P_NODO_ARBOL arbol, int i){
    
    if (arbol == NULL){
       return 0;
    }
    if (arbol->valor == i){ 
                     return 1;
    }
    if (arbol->valor > i){
          return pertenece(arbol->izq, i);
    }else{
          return pertenece(arbol->der, i);
    }
}

P_NODO_ARBOL encontrar(P_NODO_ARBOL arbol, int i){ 
             
             if (arbol == NULL){ 
                       return NULL; 
             } 
             if (arbol->valor == i){ 
                       return arbol;
             } 
             if (arbol->valor > i){
                   return encontrar(arbol->izq, i); 
             }else{ 
                   return encontrar(arbol->der, i);
             } 
}

P_NODO_ARBOL padre_de(P_NODO_ARBOL arbol, P_NODO_ARBOL nodo){ 
             
             if (arbol == NULL){ 
                       return NULL; 
             } 
             if (arbol->izq == nodo || arbol->der == nodo){ 
                            return arbol; 
             }else{
                   if (arbol->valor > nodo->valor){ 
                                    return padre_de(arbol->izq, nodo); 
                   }else{ 
                          return padre_de (arbol->der, nodo); 
                   }
             }
}

P_NODO_ARBOL eliminar (P_NODO_ARBOL a, int i){
             
    P_NODO_ARBOL q,p;
    if (a == NULL){ 
          return a;
    }
    if (a->valor > i){ 
                 a-> izq = eliminar (a->izq, i);
    }else{ 
           if (a->valor < i){ 
                        a-> der = eliminar (a->der, i);
           }else{
                 if ((a->der == NULL)&&(a->izq == NULL)){ //Caso 1
                             free(a);
                             return 0;
                            // return borraNodo(a);
                 }
    
                if (a->der == NULL){ //Caso 2
                    q = a->izq;
                    free (a);
                    return q;
                }
                
                if (a->izq == NULL){
                    q = a->der;
                    free (a);
                    return q;
                }
                //Caso 3
                for(p=a,q=a->izq; q->der != NULL; q = q->der){
                                  p=q;
                }
                if (p!=a){
                      p-> der = q->izq;
                }else{
                      p->izq =q->izq;
                }
                a->valor =q->valor;
                free(q);
        }
    }
    return a;
}

void orden_previo(P_NODO_ARBOL arbol){
      if (arbol != NULL){
                printf("\n%d ", arbol->valor);
                orden_previo(arbol->izq);
                orden_previo(arbol->der);
      }     
}

void orden_simetrico(P_NODO_ARBOL arbol){
     if (arbol != NULL){
              orden_simetrico(arbol->izq);
              printf("\n%d ", arbol->valor);
              orden_simetrico(arbol->der);
     }
}
 
void orden_posterior(P_NODO_ARBOL arbol){
     if (arbol != NULL){
              orden_posterior(arbol->izq);
              orden_posterior(arbol->der);
              printf("\n%d ", arbol->valor);
     }
}

int main(void){

    int opcion, orden_opc, aux;
    P_NODO_ARBOL a = NULL;
    
    do{
        printf("\n\n1.Insertar\n");
        printf("2.Pertenece\n");
        printf("3.Encontrar\n");
        printf("4.Padre de\n");
        printf("5.Borrar\n");
        printf("6.Recorridos\n");
        printf("7.Salir\n");
        printf("\nIntroduce una opcion: ");
        scanf("%d",&opcion);
    
        switch (opcion){
            case 1: printf("\nNumero a insertar: ");
                    scanf("%d",&aux);
                    a = insertar(a, aux);
                    printf("\nElemento insertado");
                    break;
    
            case 2: printf("\nNumero a buscar: ");
                    scanf("%d",&aux);
                    if(pertenece(a, aux)){
                          printf("\nPertenece");
                    }else{
                           printf("\nNo pertenece");
                    }
                    break;
            
            case 3: printf("\nNumero a encontrar: ");
                    scanf("%d",&aux);
                    if(encontrar(a, aux) != NULL){
                                    printf("\nElemento en nodo: %d", encontrar(a, aux)->valor);
                    }else{
                          printf("\nNo encontrado");    
                    }
                    break;
            
            case 4: printf("\nNumero padre de: ");
                    scanf("%d",&aux);
                    if(padre_de(a, encontrar(a, aux)) != NULL){
                                   printf("\nPadre: %d", padre_de(a, encontrar(a, aux))->valor);
                    }else{
                           printf("\nNo tiene padre");     
                    }
                    break;
            
            case 5: printf("\nNumero a eliminar: ");
                    scanf("%d",&aux);
                    a = eliminar(a, aux);
                    printf("\nElemento eliminado");
                    break;
            
            case 6: printf("\n1.Orden previo\n");
                    printf("2.Orden simetrico\n");
                    printf("3.Orden posterior\n");
                    printf("\nIntroduce una opcion: ");
                    scanf("%d",&orden_opc);
                    
                    switch (orden_opc){
                        case 1: orden_previo(a);
                                break;
                
                        case 2: orden_simetrico(a);
                                break;
                        
                        case 3: orden_posterior(a);
                                break;
                    }
                    break;
        }
    
    }while (opcion != 7);
    
    system("pause");
    return 0;    
}
