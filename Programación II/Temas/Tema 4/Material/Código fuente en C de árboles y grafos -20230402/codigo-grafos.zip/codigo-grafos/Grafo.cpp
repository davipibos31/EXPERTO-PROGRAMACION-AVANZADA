#include <stdio.h>
#include <stdlib.h>


typedef struct arco{
       struct arco *sgte;
       struct nodo *apunta;
}ARCO, *P_ARCO;

typedef struct nodo{
       char nombre; 
       struct nodo *sgte;
       struct arco *apunta;
}NODO, *P_NODO;


P_NODO buscar(P_NODO n, char nombre){
       
    P_NODO paux = n;
    while (paux != NULL) {
        if(paux->nombre == nombre){
                return paux;
        }else{
              paux = paux->sgte;
        }
    } 
    return NULL;
}

void listarArcos(P_NODO n){
     
    char c;
    printf("\nIntroduce el nombre del nodo: ");
    fflush(stdin);
    scanf("%c", &c);
    
    P_ARCO arc;
    P_NODO paux = buscar(n, c);
    if(paux == NULL){
            printf("\n***El nodo no existe");
    }else{
        printf("\nNodo: %c ", paux->nombre);
        arc=paux->apunta;
        while (arc != NULL) {
            printf("-> arco: %c ", arc->apunta->nombre);
            arc = arc-> sgte;
        }
    }
} 


void listarNodos(P_NODO n){
     
    P_NODO paux = n;
    
    while (paux!= NULL) {
        printf("\nNodo: %c ", paux->nombre);
        paux = paux->sgte;
    } 
}

P_NODO nuevo(P_NODO n, char nombre){       
    
    if(buscar(n, nombre) == NULL){
        P_NODO paux = (P_NODO) malloc(sizeof (NODO)); 
        paux->nombre = nombre;
        paux->apunta = NULL;
        
        if (n == NULL){
              paux->sgte = NULL;
        }else{
              paux->sgte = n;    
        }
        
        n = paux;
        printf("\nNodo creado\n");
    }else{
        printf("\nNodo ya creado\n");
    }
    return n;
}

void arco(P_NODO origen, P_NODO destino){
       
    P_ARCO paux = (P_ARCO) malloc(sizeof (ARCO)); 
    
    paux->apunta = destino;
    paux->sgte = origen->apunta;  
    origen->apunta = paux; 
}

int main(void){

    int opcion, orden_opc;
    char aux, aux2, aux3, aux4, nombre;
    P_NODO n = NULL;
    P_NODO aux_origen, aux_destino;
    
    do{
        printf("\n\n1.Nuevo nodo\n");
        printf("2.Nuevo arco\n");
        printf("3.Imprimir nodos\n");
        printf("4.Imprimir arcos\n");
        printf("5.Salir\n");
        printf("\nIntroduce una opcion: ");
        scanf("%d",&opcion);
    
        switch (opcion){
                    
            case 1: printf("\nNodo a insertar: ");
                    fflush(stdin);
                    scanf("%c", &nombre);
                    n = nuevo(n, nombre);
                    break;
                    
            case 2: printf("\nNodo origen: ");
                    fflush(stdin);
                    scanf("%c", &aux);
                    printf("\nNodo destino: ");
                    fflush(stdin);
                    scanf("%c", &aux2);
                    
                    if((aux_origen = buscar(n, aux)) == NULL){
                                   
                          printf("\nEl nodo origen no existe, desea darlo de alta? (S/N): ");
                          fflush(stdin);
                          scanf("%c", &aux4);
                          if(aux4 == 'S'){
                               n = nuevo(n, aux); 
                               aux_origen = buscar(n, aux);    
                          }else{
                                printf("\nNo se puede crear porque no existe nodo");
                                break;      
                          }
                    }
                    if(aux_origen != NULL){
                        if((aux_destino = buscar(n, aux2)) != NULL){ 
                              arco(aux_origen, aux_destino);         
                        }else{
                              printf("\nEl nodo destino no existe, desea darlo de alta? (S/N): ");
                              fflush(stdin);
                              scanf("%c", &aux3);
                              if(aux3 == 'S'){
                                   n = nuevo(n, aux2); 
                                   aux_destino = buscar(n,aux2);
                                   arco(aux_origen, aux_destino); 
                              }else{
                                    printf("\nNo se puede crear porque no existe nodo");
                                    break;     
                              }
                        }
                    }else{
                          printf("\nNo se puede crear porque no existe nodo");
                          break; 
                    }
                    break;
            
            case 3: listarNodos(n);
                    break;
            
            case 4: listarArcos(n);
                    break;
        }
    
    }while (opcion != 5);
    
    
    system("pause");
    return 0;    
}
