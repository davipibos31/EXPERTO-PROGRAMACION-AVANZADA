
#include <stdlib.h> 
#include <stdio.h> 
#include <assert.h> 

//cola circular doblemente enlazada

struct nodo { 
       struct nodo *pant; 
       int elemento; 
       struct nodo *psig; 
}; 


typedef struct nodo *Lista; 
typedef struct nodo *Posicion; 

struct nodo* l_int_crear(void) 
{ 
   return (NULL); 
} 
struct nodo* l_int_insertar(struct nodo *l, struct nodo *pindice, int n) 
{ 
    struct nodo *paux; 
 
    paux = (nodo *) malloc(sizeof (struct nodo));
    
    if (paux != NULL) {
       paux->elemento = n; 
    
       if (l == NULL) {
          paux->pant = paux;
          paux->psig = paux;
          l = paux;

        
       }
       else {  
   
        paux->pant = pindice;
        paux->psig = pindice->psig;
        pindice->psig = paux; 
        paux->psig->pant=paux;

    } 
   }

    return(l);
} 

struct nodo* l_int_inser_ppo(struct nodo *l, int n)
{ 
    struct nodo *paux, *paux2;
 
    paux = (nodo *) malloc(sizeof (struct nodo));
    
    if (paux != NULL) {
       paux->elemento = n; 
    
       if (l == NULL) {
          paux->pant = paux;
         paux->psig = paux;
          l = paux;

       }
       else {  


        l->pant->psig = paux;
        
        paux->pant=l->pant;
        
        paux->psig = l->psig; 
        
        l->pant=paux;
        
        l = paux; 
    } 
   }
    return (paux); 
} 


struct nodo* l_int_primero(struct nodo *l) 
{ 
    return (l);   
} 


struct nodo* l_int_ultimo(struct nodo *l) 
{ 
    struct nodo *paux;
    paux = l;

    return (l->pant); 
} 


struct nodo* l_int_siguiente(struct nodo *l, struct nodo *pindice) 
{ 

    return (pindice->psig); 
} 

struct nodo* l_int_anterior(struct nodo *l, struct nodo *pindice) 
{ 
  
    if  (l == NULL) return(NULL);
    else {
    
      return (pindice->pant); 
}
} 

int l_int_longitud(struct nodo *l) 
{ 
    int contador; 
    struct nodo *paux; 
    paux = l; 
    contador = 1;

    while (paux->psig != l) {

        contador++; 
        paux = paux->psig; 
    } 
    return (contador);
} 

struct nodo* l_int_localizar(struct nodo *l, const int posicion) 
{ 
    struct nodo* paux; 
    int c; 
    paux = l; 
    c = posicion; 
    while ( (c > 1) && (paux->psig != l) ) {
        paux = paux->psig; 
        c--; 
    }
    if(c != 1 ) paux = NULL; 
    return (paux); 
} 


int l_int_elemento(struct nodo *l, struct nodo *pindice) 
{ 
    return (pindice->elemento); 
} 

void l_int_borrar(struct nodo *l, struct nodo *pindice) 
{ 
  struct nodo *paux; 
  
  //if (l == pindice) {
       l=pindice->psig;      
  //} /*else{*/
  		//pindice->psig->pant=pindice->pant;
     	//pindice->pant->psig=pindice->psig;
     	//l=pindice->psig;
	/*}*/
  free(pindice);
}

void l_int_destruir (struct nodo *l) 
{ 
    struct nodo *pborra; 
    struct nodo *paux; 
    paux=l; 
    do { 
        pborra = paux; 
        paux =paux->psig; 
        free (pborra); 
    } while (paux != l);
}

int main(void){
    
    Lista cola;
    int opcion, elem;
    int i = 1;
    int conta=0;
    Lista auxi;
    
    do{
    	printf("------------------------\n");
        printf("1)Crear\n");
        printf("2)vacia?\n");
        printf("3)Tope\n");
        printf("4)Push\n");
        printf("5)Pop\n");
        printf("6)Listar\n");
        printf("0)Salir\n");
        printf("------------------------\n");
		printf("\nopcion: ");
        scanf("%d",&opcion);
        
    
        switch (opcion){
            case 1: cola = l_int_crear();
                    break;
    
            case 2: if(cola == NULL){
                          printf("\n\nLa cola esta vacia");
                    }else{
                          printf("\n\nLa cola no esta vacia");
                    }
                    break;
            
            case 3: if(cola != NULL){
                          printf("\nEl elemento es: %d", l_int_elemento(cola, l_int_primero(cola)));
                    }else{
                          printf("\n\nLa cola esta vacia");  
                    }
                    break;
            
            case 4: printf("\nIntroduce elemento: ");
                    scanf("%d", &elem);
                    
                    if(cola != NULL){  
                          cola = l_int_insertar(cola, l_int_ultimo(cola), elem);      
                    }else{
                          cola = l_int_inser_ppo(cola, elem);
                    }
                    break;
            
            case 5: if(l_int_longitud(cola) != 0){
                          l_int_borrar(cola, l_int_primero(cola));
                          cola=cola->psig;
                          conta++;
                    }else{
                          printf("\n\nLa cola esta vacia");  
                    }
                    break;
            
            case 6: 
            		auxi=cola;
            		i=1;
                    while (i-1 < l_int_longitud(cola)-conta){
                          printf ("%d ",auxi->elemento);
                          printf("\n");
                          auxi=auxi->psig;
                          i++;
                    }
                    break;
        }
    
    }while (opcion != 0);
    
    system("pause");
    return (0);     
}
