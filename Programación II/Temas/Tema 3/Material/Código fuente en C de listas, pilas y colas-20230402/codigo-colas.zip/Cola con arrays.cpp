/*
  Programa Cola version estatica.
*/

#include <stdlib.h> 
#include <stdio.h> 
#include <assert.h> 

#define MAX_ELEMS 10

typedef struct Cola{ 
        int cabeza,cola; 
        int valores[MAX_ELEMS];
}*tipo_cola;

tipo_cola crear(tipo_cola c){
     c = (tipo_cola) malloc(sizeof (Cola));
     c->cabeza = 0;
     c->cola = 0;
     return c;
}

int suma_uno(int i){ 
    return ((i+1) % MAX_ELEMS);
}

int primero(tipo_cola c){
         return (c->valores[c->cabeza]);
}

void apilar(tipo_cola c, int i){
    if (suma_uno(c->cola) == c->cabeza){
          printf("Error: cola llena \n");
    }else{
          c->valores[c->cola] = i;
          c->cola = suma_uno(c->cola);
    }
}

void suprime(tipo_cola c){
    if(c->cabeza == c->cola){
          printf("Error: cola vacia\n");
    }else{
          c->cabeza = suma_uno(c->cabeza);
    }
}

int main(void){
    
    tipo_cola cola;
    int opcion, elem, i;
    int cont = 0;
    int cont2 = 0;
    
    do{
        printf("\n\n1.Crear cola\n");
        printf("2.Esta vacia?\n");
        printf("3.Primero\n");
        printf("4.Inserta\n");
        printf("5.Suprime\n");
        printf("6.Listar\n");
        printf("7.Salir\n");
        printf("\nIntroduce una opcion: ");
        scanf("%d",&opcion);
    
        switch (opcion){
            case 1: cola = crear(cola);
                    cont = 0;
                    cont2 = 0;
                    break;
    
            case 2: if(cola->cabeza == cola->cola){
                          printf("\n\nLa lista esta vacia");
                    }else{
                          printf("\n\nLa lista no esta vacia");
                    }
                    break;
            
            case 3: if(cola->cabeza == cola->cola){
                          printf("\n\nLa lista esta vacia");
                    }else{
                          printf("\n\nEl numero es: %d", primero(cola));
                    }
                    break;
            
            case 4: printf("\nIntroduce elemento: ");
                    scanf("%d", &elem);
                    apilar(cola, elem);
                    cont ++;
                    break;
            
            case 5: suprime(cola);
                    cont2++;
                    break;
            
            case 6: for(i = cont2; i < cont; i++){
                            printf ("%d ", cola->valores[i]);
                            printf("\n"); 
                    }
                    break;
        }
    
    }while (opcion != 7);
    
    system("pause");
    return (0);     
}
