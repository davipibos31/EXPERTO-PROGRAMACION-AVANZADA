/*
  Programa Pila.
*/

#include <stdlib.h> 
#include <stdio.h> 
#include <assert.h> 

struct nodo { 
    int elemento; 
    struct nodo *psig; 
}; 


typedef struct nodo *Lista; 
typedef struct nodo *Posicion; 

struct nodo* l_int_crear(void) 
{ 
   return (NULL); 
} 
struct nodo* l_int_insertar(struct nodo *l, struct nodo *pindice, int n) 
{ 
    struct nodo *paux; 
 
    paux = (nodo *) malloc(sizeof (struct nodo));
    
    paux->elemento = n;
    paux->psig = pindice->psig;
    pindice->psig = paux;

    return(l);
} 

struct nodo* l_int_inser_ppo(struct nodo *l, int n)
{ 
    struct nodo *paux; 
 
    paux = (nodo *) malloc(sizeof (struct nodo));
    paux->elemento = n;
    paux->psig = NULL;
    l = paux;
    return (paux); 
} 


struct nodo* l_int_primero(struct nodo *l) 
{ 
   
    return (l);   
} 


struct nodo* l_int_ultimo(struct nodo *l) 
{ 
    struct nodo *paux;    /*El �ltimo elemento de la lista es NULL.*/ 
    paux = l; 
    while (paux->psig != NULL) 
        paux = paux->psig; 
    return (paux); 
} 


struct nodo* l_int_siguiente(struct nodo *l, struct nodo *pindice) 
{ 

    return (pindice->psig); 
} 

struct nodo* l_int_anterior(struct nodo *l, struct nodo *pindice) 
{ 
    struct nodo *paux; 
    if ((pindice == l) || (l == NULL)) return(NULL);
    else {
      paux = l; 
      while (paux->psig != pindice) 
        paux=paux->psig; 
      return (paux); 
   }  
} 

int l_int_longitud(struct nodo *l) 
{ 
    int contador; 
    struct nodo *paux; 
    if(l == NULL){
         return(0);
    }
    paux = l; 
    contador = 1;
    while (paux->psig != NULL) { 

        contador++; 
        paux = paux->psig; 
    } 
    return (contador);
} 

struct nodo* l_int_localizar(struct nodo *l, const int posicion) 
{ 
    struct nodo* paux; 
    int c; 
    paux = l; 
    c = posicion; 
    while ( (c > 1) && (paux->psig != NULL) ) { 
        paux = paux->psig; 
        c--; 
    }
    if(c != 1 ) paux = NULL; 
    return (paux); 
} 


int l_int_elemento(struct nodo *l, struct nodo *pindice) 
{ 
    return (pindice->elemento); 
} 

void l_int_borrar(struct nodo *l, struct nodo *pindice) 
{ 
  struct nodo *paux; 
  if (l == pindice) {
     l=pindice->psig;
     free(pindice);
       
  }
  else {    
  paux = l_int_anterior(l,pindice);
  paux->psig=pindice->psig; 
  free(pindice); 
 }
} 

void l_int_destruir (struct nodo *l) 
{ 
    struct nodo *pborra; 
    struct nodo *paux; 
    paux=l; 
    do { 
        pborra = paux; 
        paux =paux->psig; 
        free (pborra); 
    } while (paux != NULL); 
}

int main(void){
    
    Lista pila;
    int opcion, elem, i;
    
    do{
        printf("\n\n1.Crear pila\n");
        printf("2.Esta vacia?\n");
        printf("3.Tope\n");
        printf("4.Push\n");
        printf("5.Pop\n");
        printf("6.Listar\n");
        printf("7.Salir\n");
        printf("\nIntroduce una opcion: ");
        scanf("%d",&opcion);
    
        switch (opcion){
            case 1: pila = l_int_crear();
                    break;
    
            case 2: if(l_int_longitud(pila) == 0){
                          printf("\n\nLa pila esta vacia");
                    }else{
                          printf("\n\nLa pila no esta vacia");
                    }
                    break;
            
            case 3: if(l_int_longitud(pila) != 0){
                          printf("\nEl elemento es: %d", l_int_elemento(pila, l_int_ultimo(pila)));
                    }else{
                          printf("\n\nLa pila esta vacia");  
                    }
                    break;
            
            case 4: printf("\nIntroduce elemento: ");
                    scanf("%d", &elem);
                    
                    if(l_int_longitud(pila) != 0){  
                          pila = l_int_insertar(pila, l_int_ultimo(pila), elem);      
                    }else{
                          pila = l_int_inser_ppo(pila, elem);
                    }
                    break;
            
            case 5: if(l_int_longitud(pila) != 0){
                          l_int_borrar(pila, l_int_ultimo(pila));
                    }else{
                          printf("\n\nLa pila esta vacia");  
                    }
                    break;
            
            case 6: for(i = 1; i-1 < l_int_longitud(pila); i++){
                            printf ("%d ",l_int_elemento(pila, l_int_localizar(pila, i)));
                            printf("\n"); 
                    }
                    break;
        }
    
    }while (opcion != 7);
    
    system("pause");
    return (0);     
}
