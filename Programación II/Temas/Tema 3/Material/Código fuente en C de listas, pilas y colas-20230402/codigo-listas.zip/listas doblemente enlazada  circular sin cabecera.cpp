#include <stdlib.h> 
#include <stdio.h> 
#include <assert.h> 

/* Lista doblemente enlazada circular sin nodo cabecera */

struct nodo { 
       struct nodo *pant; 
    int elemento; 
    struct nodo *psig; 
}; 


typedef struct nodo *Lista; 
typedef struct nodo *Posicion; 

struct nodo* l_int_crear(void) 
{ 
   return (NULL); 
} 
struct nodo* l_int_insertar(struct nodo *l, struct nodo *pindice, int n) 
{ 
    struct nodo *paux; 
 
    paux = (nodo *) malloc(sizeof (struct nodo));
    
    if (paux != NULL) {
       paux->elemento = n; 
    
       if (l == NULL) {
          paux->pant = paux;
          paux->psig = paux;
          l = paux;

        
       }
       else {  
   
        paux->pant = pindice;
        paux->psig = pindice->psig;
        pindice->psig = paux; 
        paux->psig->pant=paux;

    } 
   }

    return(l);
} 

struct nodo* l_int_inser_ppo(struct nodo *l, int n)
{ 
    struct nodo *paux, *paux2;
 
    paux = (nodo *) malloc(sizeof (struct nodo));
    
    if (paux != NULL) {
       paux->elemento = n; 
    
       if (l == NULL) {
          paux->pant = paux;
         paux->psig = paux;
          l = paux;

       }
       else {  


        l->pant->psig = paux;
        
        paux->pant=l->pant;
        
        paux->psig = l->psig; 
        
        l->pant=paux;
        
        l = paux; 
    } 
   }
    return (paux); 
} 


struct nodo* l_int_primero(struct nodo *l) 
{ 
   
    return (l);   
} 


struct nodo* l_int_ultimo(struct nodo *l) 
{ 
    struct nodo *paux;
    paux = l;

    return (l->pant); 
} 


struct nodo* l_int_siguiente(struct nodo *l, struct nodo *pindice) 
{ 

    return (pindice->psig); 
} 

struct nodo* l_int_anterior(struct nodo *l, struct nodo *pindice) 
{ 
  
    if  (l == NULL) return(NULL);
    else {
    
      return (pindice->pant); 
}
} 

int l_int_longitud(struct nodo *l) 
{ 
    int contador; 
    struct nodo *paux; 
    paux = l; 
    contador = 1;

    while (paux->psig != l) {

        contador++; 
        paux = paux->psig; 
    } 
    return (contador);
} 

struct nodo* l_int_localizar(struct nodo *l, const int posicion) 
{ 
    struct nodo* paux; 
    int c; 
    paux = l; 
    c = posicion; 
    while ( (c > 1) && (paux->psig != l) ) {
        paux = paux->psig; 
        c--; 
    }
    if(c != 1 ) paux = NULL; 
    return (paux); 
} 


int l_int_elemento(struct nodo *l, struct nodo *pindice) 
{ 
    return (pindice->elemento); 
} 

void l_int_borrar(struct nodo *l, struct nodo *pindice) 
{ 
  struct nodo *paux; 
  pindice->psig->pant=pindice->pant;
     pindice->pant->psig=pindice->psig;
  if (l == pindice) {
       l=pindice->psig;      
  }
 
 
    
     
 free(pindice);
} 

void l_int_destruir (struct nodo *l) 
{ 
    struct nodo *pborra; 
    struct nodo *paux; 
    paux=l; 
    do { 
        pborra = paux; 
        paux =paux->psig; 
        free (pborra); 
    } while (paux != l);
}


int main(int argc, char** argv) 
{ 
    Lista a; 
    Posicion c1; 
    int conta; 
    a = l_int_crear(); 
   

    c1 = l_int_primero(a); 
    printf("Insertando los n�meros (del 0 al 20): "); 
    for (conta = 0; conta <= 20; conta++) { 
        printf("%d ",conta); 
        a=l_int_insertar(a,c1,conta);
        c1=l_int_ultimo(a);

        
    } 

    printf("\n"); 
/*-------------------------------------------------------------------------*/ 
    printf("La lista contiene %d n�meros\n", l_int_longitud(a)); 
/*-------------------------------------------------------------------------*/ 
    printf("Sacamos los n�meros de la lista (en orden): "); 
    c1 = l_int_primero(a); 
    for (conta = 0; conta < l_int_longitud(a); conta ++) {
        
        printf("%d ",l_int_elemento(a, c1));
        c1=l_int_siguiente(a, c1);


    } 
    printf("\n"); 
/*-------------------------------------------------------------------------*/ 
    printf("Sacamos de nuevo los n�meros de la lista (en orden): "); 
    c1 = l_int_primero(a); 
    while (c1 != l_int_ultimo(a)) {

             printf ("%d ",l_int_elemento(a, c1));
             c1=l_int_siguiente(a, c1);

    }
    printf ("%d ",l_int_elemento(a, c1));
    printf("\n"); 
/*-------------------------------------------------------------------------*/ 
    printf("\nSacamos los n�meros de la lista (al rev�s): "); 
    c1 = l_int_ultimo(a); 
    for (conta = 0; conta < l_int_longitud(a); conta ++) { 
        printf("%d ", l_int_elemento(a, c1));
        c1 = l_int_anterior(a,c1); /*El �ltimo elemento es NULL*/ 
} 
/*-------------------------------------------------------------------------*/ 
    c1=l_int_localizar(a,8); 
    if (c1 !=NULL)
    printf("\nEn la posicion 8 (se numeran de 0 a ?) se encuentra: %d\n" 
            , l_int_elemento(a, c1)); 
    c1=l_int_localizar (a,200); 
    if (c1 !=NULL)
    printf("\nEn la posicion 200 (se numeran de 0 a ?) se encuentra: %d\n" 
            , l_int_elemento(a, c1)); 
/*-------------------------------------------------------------------------*/ 
    printf("Vamos a eliminar el elemento 8, la lista queda: "); 
    c1=l_int_localizar(a,8); 
    l_int_borrar(a, c1); 
    c1 = l_int_primero(a); 
    for (conta = 0; conta < l_int_longitud(a); conta ++) { 
         printf("%d ",l_int_elemento(a, c1));
         c1=l_int_siguiente(a, c1); 

    } 
/*-------------------------------------------------------------------------*/ 
    printf("Borramos\n"); 
    l_int_destruir(a); 

    system("PAUSE");
    return (EXIT_SUCCESS); 
} 
